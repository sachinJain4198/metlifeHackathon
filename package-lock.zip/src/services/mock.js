export const mockItems = [
  { id: 1, title: 'First', description: 'First item' },
  { id: 2, title: 'Second', description: 'Second item' },
  { id: 3, title: 'Third', description: 'Third item' },
]
